package com.example.itsukakotori.calculator;

/**
 * Created by Itsuka Kotori on 2/24/2018.
 */

public class MathOperation {

    public double add(double x, double y){
        return x+y;
    }

    public double substract(double x, double y){
        return x-y;
    }

    public double multiply(double x, double y){
        return x*y;
    }

    public double divide(double x, double y){
        return x/y;
    }
}
